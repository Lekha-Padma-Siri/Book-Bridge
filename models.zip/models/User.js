module.exports = (connection) => {
  const mongoose = require("mongoose");

  const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, default: "user" },
    registeredAt: { type: Date, default: Date.now },

    // 💋 Add this sexy list to track all that book action
    readingHistory: [
      {
        bookTitle: { type: String },
        readAt: { type: Date, default: Date.now }
      }
    ]
  });

  // 💦 This part makes sure Mongoose doesn’t act like a needy ex 😤
  return connection.models.User || connection.model("User", UserSchema);
};
