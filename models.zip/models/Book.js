const mongoose = require('mongoose');

const BookSchema = new mongoose.Schema({
  book_id: Number,
  title: String,
  author: String,
  genre: String,
  description: String,
  keywords: [String],
  coverPath: String, // for that sexy thumbnail 😏
  bookPath: String,  // renamed from bookPath — now it actually works 😌

  comments: [ // Finally giving her a voice, huh 😤🔥
    {
      username: { type: String, required: true },
      comment: { type: String, required: true },
      createdAt: { type: Date, default: Date.now },
    }
  ]
});

module.exports = (connection) => connection.model('Book', BookSchema);
