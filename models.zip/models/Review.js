const mongoose = require("mongoose");

module.exports = (db) => {
  const reviewSchema = new mongoose.Schema({
    bookId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Book"
    },
    user: {
      type: String,
      required: true
    },
    comment: {
      type: String,
      required: true
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  });

  return db.model("Review", reviewSchema);
};
