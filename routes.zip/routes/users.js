const express = require("express");
const mongoose = require("mongoose");

module.exports = function (loginDB) {
  const router = express.Router();

  const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String, // probably exists in the real schema
    role: { type: String, default: "user" }, // 🧠 default role is "user"
    registeredAt: { type: Date, default: Date.now },
    readingHistory: [
      {
        bookTitle: String,
        readAt: Date
      }
    ]
  });

  const User = loginDB.model("User", userSchema, "users");

  router.get("/", async (req, res) => {
    try {
      const users = await User.find({ role: { $ne: 'admin' } }); // ❌ exclude admin
      res.json(users);
    } catch (err) {
      console.error("💀 Error fetching users:", err);
      res.status(500).json({ error: "Shit broke. Try again, babe." });
    }
  });

  return router;
};
