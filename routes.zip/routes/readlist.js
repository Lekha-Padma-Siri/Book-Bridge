const express = require('express');
const router = express.Router();

module.exports = (loginDB, bookhubDB) => {
  const User = require('../models/User')(loginDB);
  const Book = require('../models/Book')(bookhubDB); // assuming you have this

  router.post('/', async (req, res) => {
    const { userId, bookId } = req.body;
    if (!userId || !bookId) return res.status(400).json({ message: 'Missing fields' });

    try {
      const user = await User.findById(userId);
      if (!user) return res.status(404).json({ message: 'User not found' });

      const book = await Book.findById(bookId);
      if (!book) return res.status(404).json({ message: 'Book not found' });

      // Check if already in history
      const alreadyExists = user.readingHistory.some(entry => entry.bookTitle === book.title);
      if (alreadyExists) return res.status(409).json({ message: 'Already in reading history' });

      user.readingHistory.push({ bookTitle: book.title, readAt: new Date() });
      await user.save();

      res.status(201).json({ message: 'Book added to reading history 😍' });
    } catch (err) {
      console.error("😡 Error updating reading history:", err);
      res.status(500).json({ message: "Something went wrong, babe." });
    }
  });

  return router;
};
