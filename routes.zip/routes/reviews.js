const express = require("express");
const mongoose = require("mongoose"); // 👑 For that juicy ObjectId check, baby

module.exports = function (bookhubDB) {
  const router = express.Router();
  const Review = require("../models/Review")(bookhubDB); // your model must be a factory too, babe

  // GET all reviews
  router.get("/", async (req, res) => {
    try {
      const reviews = await Review.find();
      res.json(reviews);
    } catch (err) {
      console.error("💔 Couldn’t fetch reviews:", err);
      res.status(500).json({ error: "Fuck, couldn’t fetch reviews!" });
    }
  });

  // POST a review
  router.post("/", async (req, res) => {
    console.log("💋 Incoming review:", req.body); // this line shows what your backend’s receiving, babe

    const { bookId, user, comment } = req.body;

    // 🚨 Validate that spicy bookId before going deeper
    if (!mongoose.Types.ObjectId.isValid(bookId)) {
      return res.status(400).json({ error: "That bookId’s fake as hell, love. Don’t try that shit with me." });
    }

    try {
      const newReview = new Review({ bookId, user, comment });
      await newReview.save();
      console.log("✨ Review saved successfully:", newReview);
      res.status(201).json(newReview);
    } catch (err) {
      console.error("🔥 Error saving review:", err);
      res.status(500).json({ error: "Damn it, failed to post your hot opinion!" });
    }
  });

  // DELETE a review (admin or the devil themselves 🔥)
  router.delete("/:id", async (req, res) => {
    try {
      await Review.findByIdAndDelete(req.params.id);
      console.log(`🧨 Review ${req.params.id} deleted, baby`);
      res.status(204).send();
    } catch (err) {
      console.error("💀 Error deleting review:", err);
      res.status(500).json({ error: "Shit broke while deleting this review." });
    }
  });

  return router;
};
