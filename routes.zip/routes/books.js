const express = require('express');

const createBooksRoute = (db) => {
  const router = express.Router();
  const Book = require('../models/Book')(db); // Inject db here, babe 😎

  // GET all books, with optional search query
  router.get('/', async (req, res) => {
    try {
      const q = req.query.q ? req.query.q.trim() : '';
      let filter = {};

      if (q) {
        const regex = new RegExp(q, 'i'); // Case-insensitive dirty search
        filter = {
          $or: [
            { title: regex },
            { author: regex },
            { genre: regex },
            { keywords: regex },
          ],
        };
      }

      const books = await Book.find(filter).lean().exec();
      res.json(books);
    } catch (err) {
      console.error("💔 Error fetching books:", err);
      res.status(500).json({ error: 'Server Error, damn it' });
    }
  });

  // GET single book by ID
  router.get('/:id', async (req, res) => {
    try {
      const book = await Book.findById(req.params.id).lean();
      if (!book) return res.status(404).json({ error: 'Book not found, babe 😢' });

      const fullBook = {
        _id: book._id,
        title: book.title,
        author: book.author,
        genre: book.genre,
        description: book.description || '',
        keywords: book.keywords || [],
        pdfPath: book.pdfPath || book.bookPath || '',

        coverPath: book.coverPath || '',
      };

      res.json(fullBook);
    } catch (err) {
      console.error("💔 Error fetching single book:", err);
      res.status(500).json({ error: 'Server Error 😤' });
    }
  });

  // DELETE a book
  router.delete('/:id', async (req, res) => {
    try {
      await Book.findByIdAndDelete(req.params.id);
      res.json({ message: 'Book deleted, just like that 💔' });
    } catch (err) {
      console.error("💔 Error deleting book:", err);
      res.status(500).json({ error: 'Delete failed, babe 😣' });
    }
  });

  // UPDATE a book
  router.put('/:id', async (req, res) => {
    try {
      const { title, author, genre, description, keywords, pdfPath, coverPath } = req.body;

      const updatedBook = await Book.findByIdAndUpdate(
        req.params.id,
        { title, author, genre, description, keywords, pdfPath, coverPath },
        { new: true, runValidators: true }
      );

      if (!updatedBook) return res.status(404).json({ error: 'Book not found, babe 😭' });

      res.json(updatedBook);
    } catch (err) {
      console.error("💔 Error updating book:", err);
      res.status(500).json({ error: 'Update failed, damn 😤' });
    }
  });

  // 💬 GET comments for a book (the missing spicy route 😘)
  router.get('/:id/comments', async (req, res) => {
    try {
      const book = await Book.findById(req.params.id).lean();
      if (!book) return res.status(404).json({ error: "No book found, love 😢" });

      res.json(book.comments || []);
    } catch (err) {
      console.error("💥 Error fetching comments:", err);
      res.status(500).json({ error: "Couldn't fetch those spicy reviews, baby 😤" });
    }
  });

  // 💥 POST a review/comment for a book
  router.post('/:id/comments', async (req, res) => {
    try {
      const book = await Book.findById(req.params.id);
      if (!book) return res.status(404).json({ error: 'Book not found, sugar 🥺' });

      const { username, comment } = req.body;

      if (!username || !comment) {
        return res.status(400).json({ error: "Missing username or comment, baby 😠" });
      }

      const newComment = {
        username,
        comment,
        createdAt: new Date()
      };

      if (!Array.isArray(book.comments)) book.comments = [];

      book.comments.push(newComment);
      await book.save();

      res.status(201).json(newComment);
    } catch (err) {
      console.error("🔥 Error posting review:", err);
      res.status(500).json({ error: 'Damn it, failed to post your opinion, love 💔' });
    }
  });

  return router;
};

module.exports = createBooksRoute;
