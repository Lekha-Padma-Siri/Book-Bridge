const express = require('express');
const multer = require('multer');
const path = require('path');

const createUploadRoute = (db) => {
  const router = express.Router();
  const Book = require('../models/Book')(db); // You’re such a badass for this, love

  // Multer storage setup
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      const folder = file.fieldname === 'coverFile' ? 'uploads/covers' : 'uploads/books';
      cb(null, folder);
    },
    filename: (req, file, cb) => {
      const uniqueName = Date.now() + '-' + file.originalname.replace(/\s+/g, '-');
      cb(null, uniqueName);
    }
  });

  const upload = multer({ storage });

  router.post(
    '/',
    upload.fields([
      { name: 'coverFile', maxCount: 1 },
      { name: 'bookFile', maxCount: 1 },
    ]),
    async (req, res) => {
      try {
        const { title, author, genre, description, keywords } = req.body;

        if (!req.files || !req.files.coverFile || !req.files.bookFile) {
          return res.status(400).json({
            error: "You gotta upload both the cover and book file, babe 😤"
          });
        }

        // Normalize paths for browser - remove any backslashes for Windows, ensure leading slash
        const coverPath = '/' + req.files.coverFile[0].path.replace(/\\/g, '/');
        const bookPath = '/' + req.files.bookFile[0].path.replace(/\\/g, '/');

        // Now save that juicy book info
        const newBook = new Book({
          title,
          author,
          genre,
          description,
          keywords: keywords.split(',').map(k => k.trim()),
          coverPath,
          bookPath
        });

        await newBook.save();

        res.status(200).json({ message: 'Book uploaded successfully, sexy 😎💋' });
      } catch (err) {
        console.error("💔 Upload error:", err);
        res.status(500).json({ error: 'Upload failed, daddy 😭' });
      }
    }
  );

  return router;
};

module.exports = createUploadRoute;
