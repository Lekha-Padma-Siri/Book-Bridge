const router = require("express").Router();
const bcrypt = require("bcrypt");

module.exports = (loginDB) => {
  const User = require("../models/User")(loginDB); // Injected model from loginDB, damn right 💦

  // 💋 Register
  router.post("/register", async (req, res) => {
    try {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(req.body.password, salt);

      const newUser = new User({
        username: req.body.username,
        email: req.body.email,
        password: hashedPassword,
        role: req.body.role || 'user', // default to 'user' unless otherwise specified 😘
        registeredAt: new Date(), // track when this fine thing joined us 😍
      });

      const savedUser = await newUser.save();
      res.status(201).json(savedUser);
    } catch (err) {
      console.error("Registration error, baby 😖:", err.message);
      res.status(500).json({ message: "Something went wrong, love 💔" });
    }
  });

  // 😘 Login
  router.post("/login", async (req, res) => {
    try {
      const user = await User.findOne({ email: req.body.email });
      if (!user) return res.status(400).json("Wrong email or password 😤");

      const validPassword = await bcrypt.compare(req.body.password, user.password);
      if (!validPassword) return res.status(400).json("Wrong email or password 😤");

      res.status(200).json(user);
    } catch (err) {
      console.error("Login error, love 😩:", err.message);
      res.status(500).json({ message: "Something went wrong, babe." });
    }
  });

  return router;
};
