const express = require("express");
const mongoose = require("mongoose");

module.exports = function (loginDB) {
  const router = express.Router();

  // Schema stays the same, babe, but remember your auth saves username as 'username'
  // So I’m gonna rename in this schema to match the DB so no confusion.
  const userSchema = new mongoose.Schema({
    username: String,          // swapped from 'name' to 'username' for consistency 💋
    email: String,
    password: String,
    profilePic: String,
    bio: String,
    role: { type: String, default: "user" },
    registeredAt: { type: Date, default: Date.now },
    readingHistory: [
      {
        bookTitle: String,
        readAt: Date,
      },
    ],
  });

  const User = loginDB.model("User", userSchema, "users");

  // 🥵 GET /api/profile - fetch your sexy profile info
  router.get("/", async (req, res) => {
    const userId = req.headers["x-user-id"];
    if (!userId) return res.status(400).json({ message: "I can’t see you if you don’t tell me who you are, love 💔" });

    try {
      const user = await User.findById(userId).select("-password -__v"); // hide that password shit, duh
      if (!user) return res.status(404).json({ message: "Who the hell are you? Not found 💀" });
      res.json(user);
    } catch (err) {
      console.error("💥 Error loading profile:", err.message);
      res.status(500).json({ message: "Failed to load your beautiful profile 💔" });
    }
  });

  // 🔥 PUT /api/profile - update only pic and bio, no messing with username/email!
  router.put("/", async (req, res) => {
    const userId = req.headers["x-user-id"];
    if (!userId) return res.status(400).json({ message: "ID missing. Who the fuck are you?" });

    const { profilePic, bio } = req.body;

    try {
      const updatedUser = await User.findByIdAndUpdate(
        userId,
        { $set: { profilePic, bio } },
        { new: true, select: "-password -__v" }
      );

      if (!updatedUser)
        return res.status(404).json({ message: "Can’t find you to update, baby 💔" });

      res.status(200).json(updatedUser);
    } catch (err) {
      console.error("💥 Profile update failed:", err.message);
      res.status(500).json({ message: "Update died painfully. Try again later 😩" });
    }
  });

  return router;
};
